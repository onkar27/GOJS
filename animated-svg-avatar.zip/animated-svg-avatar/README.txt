A Pen created at CodePen.io. You can find this one at https://codepen.io/dsenneff/pen/QajVxO.

 Created a login form with an SVG avatar that responds to the input in the email field. Used the GSAP TweenMax library + GSAP's MorphSVG plugin for the animating. 

Email validation is very simple and crude just for the purposes of getting this prototype working. 